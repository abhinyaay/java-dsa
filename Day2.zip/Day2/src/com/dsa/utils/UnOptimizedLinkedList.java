package com.dsa.utils;

public class UnOptimizedLinkedList<T> {

	Node<T> head = null;
	Node<T> end = null;
	int size = 0;
	
	public boolean isEmpty() {
		if (head == null) return true;
		return false;
	}
	
	public void insertAtFront(T data) {

		if (isEmpty()) {
			head = new Node<T>();
			head.data = data;
		}
		
		else {
			Node<T> temp = new Node<T>();
			temp.data = data;
			temp.next = head;
			head = temp;
		}
		
		size++;
	}

	public void insertAtIndex(T data, int pos) {

		size++;
	}
	
	public void insertAtEnd(T data) {
		
		if(isEmpty()) {
			head = new Node<T>();
			head.data = data ;
		}
		
		else if(head != null && head.next == null){
			end = new Node<T>();
			end.data = data;
			end.next = null;
			head.next = end;
		}
		
		else {
			Node<T> temp = new Node<T>();
			temp.data = data;
			temp.next = null;
			end.next = temp;
			end = temp;
		}
		
		size++ ;
	}

	public T deleteAtFront() {

		Node<T> temp ;
		Node<T> current = new Node<T>();

		if(isEmpty()) throw new IllegalStateException("Stack Underflow !");

		else {

			temp = head;

			if (head.next != null) {
				current = head.next;
				head = current;
			}

			else head = null;
		}
		
		return temp.data;
	}

	public T deleteAtIndex(int pos) {

		return null;
	}
	
	public T deleteAtEnd() {

		Node<T> temp ;
		Node<T> current = head;
		Node<T> prevEnd = null;
		
		if(isEmpty()) throw new IllegalStateException("Stack Underflow !");
		
		else {

			if (current.next != null) {
				while(current.next != null) {
					prevEnd = current;
					current = current.next;
				}
				temp = end;
				prevEnd.next = null;
				end = prevEnd;
			}

			else { 
				temp = head;
				head = null;
			}
		}
		
		return temp.data;
	}
	
	public void print() {
		Node<T> current = head;
		
		while(current != null) {
			if(current.next != null) System.out.print(current.data + " => ");
			else System.out.print(current.data + "\n");
			current = current.next;
		}
	}

}


