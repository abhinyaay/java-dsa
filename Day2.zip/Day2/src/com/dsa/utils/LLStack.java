package com.dsa.utils;

@SuppressWarnings("unchecked")
public class LLStack<T> implements Stack<T> {

	Node<T> top = null;
	int size = 0;
	
	@Override
	public boolean isEmpty() {
		if (top == null)
			return true;
		return false;
	}

	@Override
	public T peek() {
		Node<T> temp ;

		if (isEmpty())
			throw new IllegalStateException("Stack Underflow !");

		else
			temp = top;

		return (T) temp;
	}

	@Override
	public T pop() {

		Node<T> temp ;
		Node<T> current = new Node<T>();

		if (isEmpty())
			throw new IllegalStateException("Stack Underflow !");

		else {

			temp = top;

			if (top.next != null) {

				current = top.next;
				top = current;

			}

			else
				top = null;
		}
		return temp.data;
	}

	@Override
	public void push(T data) {
	
		if (isEmpty()) {
			top = new Node<T>();
			top.data = data;
		}
		
		else {
			Node<T> temp = new Node<T>();
			temp.data = data;
			temp.next = top;
			top = temp;
		}
		
		size++;
		
	}
	
	public void print() {
		Node<T> current = top;
		
		while(current != null) {
			if(current.next != null) System.out.print(current.data + " => ");
			else System.out.print(current.data + "\n");
			current = current.next;
		}
	}

}
